import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {Assets,LEVEL_ASSETS,boundedLoad,loadPool} from '../dist/assets.js';
const manifest=JSON.parse(await fs.readFile(new URL('../dist/assets/sprites.json',import.meta.url)));
const rigData=JSON.parse(await fs.readFile(new URL('../dist/assets/rigs.json',import.meta.url)));
const soundData=JSON.parse(await fs.readFile(new URL('../dist/assets/audio.json',import.meta.url)));
globalThis.window={};
class TestAssets extends Assets{
 constructor(){super();this.requests=[];this.failOnce=null;}
 async json(url,signal){assert.equal(signal.aborted,false);this.requests.push(url);return structuredClone(url.endsWith('sprites.json')?manifest:url.endsWith('rigs.json')?rigData:soundData);}
 async image(url,signal){if(signal.aborted)throw signal.reason;this.requests.push(url);if(this.failOnce===url){this.failOnce=null;throw new Error('network failure');}return {url,width:100,height:100};}
 async loadSound(key,signal){if(signal.aborted)throw signal.reason;this.buffers[key]={};}
}
test('homepage asset constructor does not fetch or decode anything',()=>{const a=new TestAssets();assert.deepEqual(a.requests,[]);assert.equal(a.readyLevels.size,0);});
test('each level prepares only its required sprites; boss textures deferred until level 4',async()=>{
 for(let id=0;id<4;id++){
  const a=new TestAssets(),progress=[];await a.loadLevel(id,(done,total)=>progress.push([done,total]));
  assert.deepEqual(Object.keys(a.images).sort(),[...LEVEL_ASSETS[id]].sort());
  assert.equal(a.requests.includes('assets/rigs.json'),id===3);
  assert.equal(!!a.rig,id===3);assert.ok(a.readyLevels.has(id));assert.deepEqual(progress.at(-1),[1,1]);
  if(id===3)assert.equal(Object.keys(a.rigImages).length,Object.keys(rigData.textures).length);
 }
});
test('replaying and changing levels reuses common decoded images',async()=>{
 const a=new TestAssets();await a.loadLevel(0);a.requests=[];await a.loadLevel(0);assert.deepEqual(a.requests,[]);
 await a.loadLevel(1);assert.deepEqual(new Set(a.requests),new Set(['repeater','cone-walk','cone-eat'].map(key=>manifest[key].url)));
});
test('failed load is retryable and does not mark the level ready',async()=>{
 const a=new TestAssets();a.failOnce=manifest.pea.url;await assert.rejects(a.loadLevel(0),/network failure/);assert.equal(a.readyLevels.has(0),false);
 await a.loadLevel(0);assert.equal(a.readyLevels.has(0),true);assert.ok(a.images.pea);
});
test('cancelled requests cannot mark readiness or start more work',async()=>{
 const a=new TestAssets(),controller=new AbortController();controller.abort();await assert.rejects(a.loadLevel(3,()=>{},controller.signal),{name:'AbortError'});assert.deepEqual(a.requests,[]);
 const running=new TestAssets(),cancel=new AbortController();
 running.image=async(url,s)=>boundedLoad(()=>new Promise(()=>{}),s,1000);
 const result=running.loadLevel(0,()=>{},cancel.signal);setTimeout(()=>cancel.abort(),10);
 await assert.rejects(result,{name:'AbortError'});assert.equal(running.readyLevels.size,0);
});
test('hung body/decode times out; retry gets a fresh deadline',async()=>{
 await assert.rejects(boundedLoad(()=>new Promise(()=>{}),undefined,10),/加载超时/);
 assert.equal(await boundedLoad(async()=>42,undefined,100),42);
});
test('pool limits concurrent decodes and reports completed items',async()=>{
 let active=0,max=0;const p=[];
 await loadPool(Array.from({length:12},()=>async()=>{max=Math.max(max,++active);await new Promise(r=>setTimeout(r,2));active--;}),new AbortController().signal,(d,t)=>p.push([d,t]));
 assert.equal(max,3);assert.deepEqual(p.at(-1),[12,12]);
});
test('aborting during image decode cannot populate an old image cache',async()=>{
 const originalFetch=globalThis.fetch,originalImage=globalThis.Image;
 globalThis.fetch=async()=>({ok:true,blob:async()=>new Blob(['test'])});
 let complete;globalThis.Image=class{decode(){return new Promise(r=>{complete=r;});}};
 const a=new Assets(),c=new AbortController(),pending=a.image('test.png',c.signal);
 await new Promise(r=>setTimeout(r,5));c.abort();await assert.rejects(pending,{name:'AbortError'});complete();
 globalThis.fetch=originalFetch;globalThis.Image=originalImage;
});
