import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('playwright');
const browser=await chromium.launch({headless:true,channel:'msedge'});
try{const p=await browser.newPage();await p.goto('http://127.0.0.1:4175');await p.evaluate(async()=>{
const {Assets}=await import('./assets.js'),a=new Assets();await a.load();const canvas=document.createElement('canvas');canvas.width=510;canvas.height=400;canvas.id='original-card';canvas.style='position:fixed;top:0;left:0;z-index:100;background:transparent';document.body.replaceChildren(canvas);const c=canvas.getContext('2d');c.translate(-440,-45);c.scale(.9,.9);a.rig.draw(c,'boss','anim_head_idle',.5);document.body.style.background='transparent';document.documentElement.style.background='transparent';
});await p.locator('#original-card').screenshot({path:'dist/assets/boss-card.png',omitBackground:true});}finally{await browser.close();}
