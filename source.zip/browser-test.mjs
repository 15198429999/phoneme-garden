import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url),{chromium}=require('playwright');
await fs.mkdir('qa',{recursive:true});
const browser=await chromium.launch({headless:true,channel:'msedge'});
try{
 const p=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],failed=[];
 p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.status()>=400)failed.push([r.status(),r.url()]);});
 await p.clock.install();await p.goto('http://127.0.0.1:4175');await p.waitForFunction(()=>window.phonicsDiagnostics?.().loaded);
 await p.screenshot({path:'qa/home.png',fullPage:true});
 await p.locator('[data-mode="easy"]').click();await p.waitForFunction(()=>[...document.querySelectorAll('.level-art img')].every(x=>x.complete&&x.naturalWidth>0));
 await p.screenshot({path:'qa/levels.png',fullPage:true,animations:'disabled'});
 await p.locator('[data-level="3"]').click();await p.waitForFunction(()=>window.phonicsDiagnostics().state==='playing');
 await p.screenshot({path:'qa/boss.png',fullPage:true,animations:'disabled'});
 await p.locator('.lane-button.ready').click();await p.waitForTimeout(600);await p.screenshot({path:'qa/corn.png',fullPage:true});
 assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).killed,0);
 await p.locator('#pause').click();const before=await p.evaluate(()=>window.phonicsDiagnostics());await p.waitForTimeout(350);const after=await p.evaluate(()=>window.phonicsDiagnostics());assert.equal(after.time,before.time);assert.equal(after.projectiles[0].age,before.projectiles[0].age);
 await p.getByRole('button',{name:'继续游戏',exact:true}).click();await p.waitForFunction(()=>window.phonicsDiagnostics().killed===1);await p.screenshot({path:'qa/boss-death.png',fullPage:true});
 for(const level of [0,1,2]){await p.locator('#select-level').click();await p.locator('[data-level="'+level+'"]').click();await p.waitForFunction(()=>window.phonicsDiagnostics().state==='playing');await p.screenshot({path:'qa/level-'+level+'.png',fullPage:true});await p.locator('.lane-button.ready').click();await p.waitForFunction(()=>window.phonicsDiagnostics().killed===1);}
 await p.locator('#brand').click();await p.locator('[data-mode="hard"]').click();assert.equal(await p.locator('.level-card').count(),4);
 await p.locator('[data-level="0"]').click();await p.waitForFunction(()=>window.phonicsDiagnostics().state==='playing');await p.clock.runFor(10500);
 const hard=await p.evaluate(()=>window.phonicsDiagnostics());assert.equal(hard.zombies.length,3,JSON.stringify(hard));assert.equal(new Set(hard.zombies.map(z=>z.row)).size,3);
 await p.screenshot({path:'qa/hard.png',fullPage:true});
 await p.clock.runFor(27000);assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).state,'lost');
 assert.equal(await p.locator('#overlay-title').textContent(),'请模仿僵尸走路或者模仿植物大战中的一个植物');await p.screenshot({path:'qa/failure.png',fullPage:true});
 await p.getByRole('button',{name:'重玩本关',exact:true}).click();assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).killed,0);
 await p.locator('#select-level').click();await p.locator('#back-home').click();await p.setViewportSize({width:390,height:844});await p.screenshot({path:'qa/mobile.png',fullPage:true});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);console.log(JSON.stringify({passed:true,consoleErrors:errors,failedRequests:failed,sprites:before.sprites.length,audioBuffers:after.audio.length,hardRows:hard.zombies.map(z=>z.row)}));
}finally{await browser.close();}
