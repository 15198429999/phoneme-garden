import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),sharp=require('sharp');
const sprites={};await fs.mkdir('dist/assets/atlas',{recursive:true});
for(const file of await fs.readdir('dist/assets')){
 if(!/\.(gif|png|webp)$/i.test(file))continue;
 const src='dist/assets/'+file,meta=await sharp(src,{animated:true}).metadata();
 const count=meta.pages||1,w=meta.width,h=meta.pageHeight||meta.height;
 const raw=await sharp(src,{animated:true}).ensureAlpha().raw().toBuffer();
 let minX=w,minY=h,maxX=0,maxY=0;
 for(let f=0;f<count;f++)for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(raw[((f*h+y)*w+x)*4+3]>8){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
 if(minX>maxX){minX=minY=0;maxX=w-1;maxY=h-1;}
 const cropW=maxX-minX+1,cropH=maxY-minY+1;
 // Animation atlases need at most twice the game's rendered height; retain originals.
 const scale=Math.min(1,220/cropH),fw=Math.round(cropW*scale),fh=Math.round(cropH*scale),cols=Math.min(count,8),rows=Math.ceil(count/cols),inputs=[];
 for(let f=0;f<count;f++){
   const frame=await sharp(raw.subarray(f*w*h*4,(f+1)*w*h*4),{raw:{width:w,height:h,channels:4}}).extract({left:minX,top:minY,width:cropW,height:cropH}).resize(fw,fh).png().toBuffer();
   inputs.push({input:frame,left:(f%cols)*fw,top:Math.floor(f/cols)*fh});
 }
 const name=file.replace(/\.[^.]+$/,'');
 await sharp({create:{width:fw*cols,height:fh*rows,channels:4,background:'#00000000'}}).composite(inputs).png().toFile('dist/assets/atlas/'+name+'.png');
 const delays=Array.from({length:count},(_,i)=>Math.max(20,meta.delay?.[i]||100));
 sprites[name]={url:'assets/atlas/'+name+'.png',width:fw,height:fh,cols,count,delays,duration:delays.reduce((a,b)=>a+b,0)/1000};
 console.log(name,fw+'x'+fh,count+' frames',sprites[name].duration+'s');
}
await fs.writeFile('dist/assets/sprites.json',JSON.stringify(sprites));
