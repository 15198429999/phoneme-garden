// A small interactive HTML shell; cacheable, original binary assets stay external.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
const out=path.resolve(process.argv[2]??'online');
await fs.mkdir(out,{recursive:true});
let html=await fs.readFile('dist/index.html','utf8');
for(const file of ['styles.css','home.css'])html=html.replace('<link rel="stylesheet" href="'+file+'">','<style>'+await fs.readFile('dist/'+file,'utf8')+'</style>');
const scripts=[];
for(const name of ['engine','rig','finale','assets','render','app'])scripts.push((await fs.readFile('dist/'+name+'.js','utf8')).replace(/^import .*\n/gm,'').replace(/^export /gm,''));
html=html.replace('<script type="module" src="app.js"></script>','<script type="module">'+scripts.join('\n')+'</script>');
await fs.copyFile('dist/credits.html',path.join(out,'credits.html'));
// Publish only files actually referenced by the game, excluding research/source files.
const sprites=JSON.parse(await fs.readFile('dist/assets/sprites.json'));
const audio=JSON.parse(await fs.readFile('dist/assets/audio.json'));
const rigs=JSON.parse(await fs.readFile('dist/assets/rigs.json'));
const files=new Set(['assets/sprites.json','assets/audio.json','assets/rigs.json',
 ...Object.values(sprites).map(s=>s.url),...Object.values(audio),...Object.values(rigs.textures).map(t=>t.url),
 ...['pea.gif','repeater.gif','fire.webp','cannon.gif','zombie-walk.gif','cone-walk.gif','bucket-walk.gif','boss-card.png','home-garden.webp','battle-garden.webp'].map(s=>'assets/'+s)]);
// Flat hashed names also permit browser upload without losing directory paths.
// Content hashes keep cached assets valid across later releases.
const urls={};
for(const file of files){const bytes=await fs.readFile('dist/'+file);const hash=createHash('sha256').update(bytes).digest('hex').slice(0,12);const name='pg-'+path.basename(file,path.extname(file))+'-'+hash+path.extname(file);urls[file]=name;await fs.writeFile(path.join(out,name),bytes);}
for(const [file,url] of Object.entries(urls))html=html.replaceAll('src="'+file+'"','src="'+url+'"').replaceAll("url('"+file+"')","url('"+url+"')");
html=html.replace('<script type="module">','<script>window.PHONICS_ONLINE='+JSON.stringify(urls)+';</script><script type="module">');
html=html.replace('<title>','<link rel="icon" href="data:,"><title>');
await fs.writeFile(path.join(out,'index.html'),html);
console.log(JSON.stringify({output:out,htmlBytes:Buffer.byteLength(html),assetFiles:files.size}));
