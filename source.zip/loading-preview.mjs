// Local QA only: real browser UI tests with slow transfer, one-shot failure and stall.
import http from 'node:http';import fs from 'node:fs/promises';import path from 'node:path';
const root=path.resolve('online');const mime={'.html':'text/html; charset=utf-8','.json':'application/json','.png':'image/png','.gif':'image/gif','.webp':'image/webp','.mp3':'audio/mpeg','.ogg':'audio/ogg'};
for(const [port,mode] of [[4175,'normal'],[4176,'slow'],[4177,'failure'],[4178,'timeout']]){
 let injected=false;const log=[];
 http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/qa-network.json'){res.writeHead(200,{'Content-Type':'application/json'}).end(JSON.stringify(log));return;}
  const file=url.pathname==='/offline.html'?path.resolve('../音标植物守卫战-双击即玩.html'):path.resolve(root,'.'+decodeURIComponent(url.pathname)+(url.pathname.endsWith('/')?'index.html':''));
  if(!file.startsWith(root+path.sep)&&url.pathname!=='/offline.html'){res.writeHead(403).end();return;}
  const entry={at:Date.now(),path:url.pathname,mode};log.push(entry);
  res.on('close',()=>{entry.closedAt=Date.now();entry.completed=res.writableFinished;});
  try{
   if(!injected&&url.pathname==='/assets/atlas/pea.png'&&['failure','timeout'].includes(mode)){
    injected=true;if(mode==='failure'){entry.status=503;res.writeHead(503).end('QA: one-shot failure');}return;
   }
   const bytes=await fs.readFile(file);entry.bytes=bytes.length;entry.status=200;
   res.writeHead(200,{'Content-Type':mime[path.extname(file)]??'application/octet-stream','Cache-Control':'no-store','Content-Length':bytes.length});
   if(mode==='slow'){
    let offset=0;const timer=setInterval(()=>{if(res.destroyed){clearInterval(timer);return;}res.write(bytes.subarray(offset,offset+4096));offset+=4096;if(offset>=bytes.length){clearInterval(timer);res.end();}},80);
    res.on('close',()=>clearInterval(timer));
   }else res.end(bytes);
  }catch{entry.status=404;res.writeHead(404).end('Not found');}
 }).listen(port,'127.0.0.1',()=>console.log(mode+': http://127.0.0.1:'+port));
}
