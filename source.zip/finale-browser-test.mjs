import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url),{chromium}=require('playwright');
const browser=await chromium.launch({headless:true,channel:'msedge'});
const url=process.env.GAME_TEST_URL||'http://127.0.0.1:4175';
try{
 const context=await browser.newContext({viewport:{width:1366,height:768},hasTouch:true});
 const p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.clock.install();await p.goto(url);await p.waitForFunction(()=>window.phonicsDiagnostics?.().screen==='home');
 await p.locator('[data-mode="hard"]').click();await p.locator('[data-level="3"]').click();
 // Play every question through the actual input buttons, using virtual time only.
 for(let i=0;i<800;i++){
  if(i%50===0)console.log('Classroom progress',i,await p.evaluate(()=>({killed:window.phonicsDiagnostics().killed,state:window.phonicsDiagnostics().state,time:window.phonicsDiagnostics().time})));
  if((await p.evaluate(()=>window.phonicsDiagnostics().boss.finaleSince))!=null)break;
  await p.locator('.lane-button.ready:not(:disabled)').evaluateAll(buttons=>buttons.forEach(b=>b.click()));
  await p.clock.runFor(500);
 }
 let d=await p.evaluate(()=>window.phonicsDiagnostics());assert.equal(d.killed,48);assert.equal(d.boss.state,'lowering');
 await p.clock.runFor(1200);
 async function visibleStage(){const b=await p.locator('#board').boundingBox(),size=await p.evaluate(()=>({width:innerWidth,height:innerHeight}));assert.ok(b.x>=0&&b.y>=0&&b.x+b.width<=size.width+1&&b.y+b.height<=size.height+1,JSON.stringify({b,size}));}
 for(const [width,height] of [[1366,768],[1920,1080],[1024,600],[844,390]]){await p.setViewportSize({width,height});await visibleStage();}
 await p.setViewportSize({width:1366,height:768});await p.screenshot({path:'qa/finale-lowered-1366.png'});
 await p.locator('#pause').click();const paused=await p.evaluate(()=>window.phonicsDiagnostics());await p.clock.runFor(10000);assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).time,paused.time);await p.getByRole('button',{name:'继续游戏',exact:true}).click();
 // Actual browser visibility event (not a synthetic document.hidden override).
 const other=await context.newPage();await other.goto('about:blank');await other.bringToFront();
 await p.bringToFront();await other.close();
 if((await p.evaluate(()=>window.phonicsDiagnostics())).state==='paused')await p.getByRole('button',{name:'继续游戏',exact:true}).click();
 await p.locator('#fullscreen').click();assert.equal(await p.evaluate(()=>!!document.fullscreenElement),true);await visibleStage();await p.locator('#fullscreen').click();
 for(let i=0;i<40;i++){if((await p.evaluate(()=>window.phonicsDiagnostics())).projectiles?.some(s=>s.kind==='corn'&&s.age>.7))break;await p.clock.runFor(200);}
 await p.screenshot({path:'qa/finale-corn-flight.png'});
 while((await p.evaluate(()=>window.phonicsDiagnostics())).boss.state!=='dying')await p.clock.runFor(100);
 await p.screenshot({path:'qa/finale-impact.png'});await p.clock.runFor(1700);await p.screenshot({path:'qa/finale-explosion.png'});
 await p.locator('#pause').click();const deathPaused=await p.evaluate(()=>window.phonicsDiagnostics());await p.clock.runFor(20000);assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).time,deathPaused.time);await p.getByRole('button',{name:'继续游戏',exact:true}).click();
 await p.clock.runFor(4600);assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).state,'playing');await p.screenshot({path:'qa/finale-white-flag.png'});
 await p.clock.runFor(2200);assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).state,'won');await p.getByRole('button',{name:'再玩本关',exact:true}).click();d=await p.evaluate(()=>window.phonicsDiagnostics());assert.equal(d.killed,0);assert.equal(d.boss.finaleSince,null);assert.equal(await p.locator('body').evaluate(b=>b.classList.contains('boss-finale')),false);assert.deepEqual(errors,[]);
 console.log('Full finale passed: 48 actual inputs, viewport fit, pause, fullscreen, projectile, explosions, flag hold, replay; '+url);
}finally{await browser.close();}
