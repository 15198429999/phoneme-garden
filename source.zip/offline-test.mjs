import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';import path from 'node:path';import assert from 'node:assert/strict';
const require=createRequire(import.meta.url),{chromium}=require('playwright');
const browser=await chromium.launch({headless:true,channel:'msedge'});
try{
const ctx=await browser.newContext({offline:true,viewport:{width:1440,height:1000}}),page=await ctx.newPage(),errors=[],network=[];
page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url());});
await page.goto(pathToFileURL(path.resolve('../音标植物守卫战-双击即玩.html')).href);await page.waitForFunction(()=>window.phonicsDiagnostics?.().screen==='home');
await page.locator('.mode-card').first().click();await page.waitForFunction(()=>[...document.querySelectorAll('.level-art img')].every(i=>i.complete&&i.naturalWidth));
await page.screenshot({path:'qa/offline-levels.png',fullPage:true,animations:'disabled'});
await page.locator('.level-card').nth(3).click();await page.waitForFunction(()=>window.phonicsDiagnostics().state==='playing');await page.locator('.lane-button.ready').click();await page.waitForTimeout(700);await page.screenshot({path:'qa/offline-corn.png',fullPage:true});await page.waitForFunction(()=>window.phonicsDiagnostics().killed===1);
const d=await page.evaluate(()=>window.phonicsDiagnostics());assert.ok(d.audio.includes('coblaunch'));assert.ok(d.audio.includes('bossdie'));assert.ok(d.boss);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);console.log(JSON.stringify({offline:true,sprites:d.sprites.length,audioBuffers:d.audio.length,cornKill:d.killed,errors,networkRequests:network.length}));
}finally{await browser.close();}
