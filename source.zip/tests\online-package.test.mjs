import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import {createHash} from 'node:crypto';
test('online shell stays small and all mapped files match the original assets',async()=>{
 const root=new URL('../online/',import.meta.url);const html=await fs.readFile(new URL('index.html',root),'utf8');
 assert.ok(Buffer.byteLength(html)<110000);assert.equal(html.includes('PHONICS_OFFLINE='),false);assert.equal(html.includes('base64,'),false);
 const urls=JSON.parse(html.match(/window.PHONICS_ONLINE=(.*?);<\/script>/)[1]);
 for(const [original,filename] of Object.entries(urls)){
  const bytes=await fs.readFile(new URL(filename,root)),source=await fs.readFile(new URL('../dist/'+original,import.meta.url));
  assert.deepEqual(bytes,source);assert.ok(filename.includes(createHash('sha256').update(bytes).digest('hex').slice(0,12)));
 }
 for(const file of ['sprites.json','rigs.json','audio.json'])assert.ok(urls['assets/'+file]);
 assert.ok(html.includes('本关素材加载进度'));assert.ok(!html.includes('aria-label="????????'));
});
