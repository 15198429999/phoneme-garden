import fs from 'node:fs/promises';
await fs.mkdir('research',{recursive:true});
for(const repo of ['jiangnangame/New-Plants-vs-Zombies-JavaScript','Jasmine709/Plants-VS-Zombies-Game','Patoke/re-plants-vs-zombies']) {
  try {
    const meta=await (await fetch('https://api.github.com/repos/'+repo)).json();
    const tree=await (await fetch('https://api.github.com/repos/'+repo+'/git/trees/'+meta.default_branch+'?recursive=1')).json();
    await fs.writeFile('research/'+repo.split('/')[0]+'.json',JSON.stringify({repo,branch:meta.default_branch,...tree}));
    console.log(repo,meta.default_branch,tree.tree?.length,JSON.stringify(tree.tree?.filter(x=>/Cob|Cannon|FirePea|Boss|chomp|groan|ZombieDie|Peashooter|Repeater|Buckethead|Conehead|Zombie\.cpp|Projectile\.cpp|LICENSE/i.test(x.path)).map(x=>x.path)));
  }catch(e){console.log(repo,e.message)}
}
