import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url),{chromium}=require('playwright');
const browser=await chromium.launch({headless:true,channel:'msedge'});
try{
 const p=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.clock.install();await p.goto('http://127.0.0.1:4175');await p.waitForFunction(()=>window.phonicsDiagnostics().loaded);await p.locator('[data-mode="hard"]').click();await p.locator('[data-level="3"]').click();
 await p.clock.runFor(800);await p.screenshot({path:'qa/boss-throw-held.png'});
 await p.clock.runFor(10200);let d=await p.evaluate(()=>window.phonicsDiagnostics());assert.equal(d.spawned,3);assert.equal(new Set(d.zombies.map(z=>z.row)).size,3);
 await p.locator('.lane-button.ready').first().click();await p.clock.runFor(1500);await p.screenshot({path:'qa/boss-cannon-raise.png'});assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).killed,0);
 await p.clock.runFor(1300);await p.screenshot({path:'qa/boss-corn-arc.png'});
 await p.locator('#pause').click();const paused=await p.evaluate(()=>window.phonicsDiagnostics());await p.clock.runFor(6000);assert.equal((await p.evaluate(()=>window.phonicsDiagnostics())).time,paused.time);await p.getByRole('button',{name:'继续游戏',exact:true}).click();await p.clock.runFor(2200);assert.ok((await p.evaluate(()=>window.phonicsDiagnostics())).killed>=1);
 await p.locator('#brand').click();
 // Complete the real engine, then inspect each finale stage with the real renderer.
 await p.evaluate(async()=>{
  const [{Game},{Assets},{Renderer}]=await Promise.all([import('./engine.js'),import('./assets.js'),import('./render.js')]);const a=new Assets();await a.load();const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=740;canvas.style='width:1200px;display:block';document.body.replaceChildren(canvas);const renderer=new Renderer(canvas,a),g=new Game({level:3});
  for(let i=0;i<20000&&(g.killed<48||g.zombies.length);i++){for(const z of g.zombies)g.fire(z.row);g.update(.1);g.drain();}
  window.qaFinal={g,renderer,advance(seconds){for(let i=0;i<Math.ceil(seconds*100);i++){g.update(.01);for(const e of g.drain())renderer.event(e,g.time);}renderer.draw(g);}};window.qaFinal.advance(4.7);
 });
 await p.screenshot({path:'qa/boss-lowered.png'});
 await p.evaluate(()=>window.qaFinal.advance(4.5));assert.equal(await p.evaluate(()=>window.qaFinal.g.boss.state),'dying');await p.screenshot({path:'qa/boss-death-start.png'});
 await p.evaluate(()=>window.qaFinal.advance(3));await p.screenshot({path:'qa/boss-death-parts.png'});
 await p.evaluate(()=>window.qaFinal.advance(3.5));await p.screenshot({path:'qa/boss-white-flag.png'});assert.equal(await p.evaluate(()=>window.qaFinal.g.state),'playing');
 await p.evaluate(()=>window.qaFinal.advance(1));assert.equal(await p.evaluate(()=>window.qaFinal.g.state),'won');assert.deepEqual(errors,[]);console.log('Boss browser checks passed: original rig, three lanes, windup, arc, pause, head lowering, collapse, white flag, delayed victory.');
}finally{await browser.close();}
