import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),sharp=require('sharp');
const fields=['x','y','kx','ky','sx','sy','f','a','i'];
function parse(xml){
 const tracks=[];
 for(const m of xml.matchAll(/<track>([\s\S]*?)<\/track>/g)){
  const name=m[1].match(/<name>(.*?)<\/name>/)[1],frames=[];let v=[0,0,0,0,1,1,0,1,null];
  for(const t of m[1].matchAll(/<t>([\s\S]*?)<\/t>/g)){
   v=[...v];for(const p of t[1].matchAll(/<(x|y|kx|ky|sx|sy|f|a|i)>(.*?)<\/\1>/g))v[fields.indexOf(p[1])]=p[1]==='i'?p[2]:Number(p[2]);frames.push(v);
  }tracks.push({name,frames});
 }
 const animations={};for(const t of tracks.filter(t=>t.name.startsWith('anim_'))){const visible=t.frames.map((f,i)=>f[6]>=0?i:-1).filter(i=>i>=0);if(visible.length)animations[t.name]=[visible[0],visible.length];}
 return {animations,tracks:tracks.filter(t=>!t.name.startsWith('anim_'))};
}
const rigs={};for(const [name,file] of [['boss','Zombie_boss'],['driver','Zombie_Boss_driver'],['cannon','CobCannon']])rigs[name]=parse(await fs.readFile('source-assets/reanim/'+file+'.reanim','utf8'));
const textures={},files=await fs.readdir('dist/assets/original');
for(const name of files.filter(x=>/\.(png|jpg)$/.test(x))){
 if(name.endsWith('_.png')||name.endsWith('.rgba.png'))continue;
 let imageFile=name;
 if(name.endsWith('.jpg')){
  const alphaName=name.replace('.jpg','_.png');
  if(files.includes(alphaName)){const alpha=await sharp('dist/assets/original/'+alphaName).extractChannel(0).toBuffer();imageFile=name.replace('.jpg','.rgba.png');await sharp('dist/assets/original/'+name).joinChannel(alpha).png().toFile('dist/assets/original/'+imageFile);}
 }
 const meta=await sharp('dist/assets/original/'+imageFile).metadata();
 textures['IMAGE_REANIM_'+name.replace(/\.[^.]+$/,'').toUpperCase()]={url:'assets/original/'+imageFile,width:meta.width,height:meta.height};
}
const needed=new Set(Object.values(rigs).flatMap(r=>r.tracks.flatMap(t=>t.frames.map(f=>f[8]).filter(Boolean))));
for(const key of needed)if(!textures[key])throw Error('Missing original texture '+key);
// Compact identical poses through shared frame arrays; animation values remain unchanged.
for(const r of Object.values(rigs)){
 const poses=[],indices=new Map();
 for(const t of r.tracks)t.frames=t.frames.map(f=>{const key=JSON.stringify(f);if(!indices.has(key)){indices.set(key,poses.length);poses.push(f);}return indices.get(key);});r.poses=poses;
}
await fs.writeFile('dist/assets/rigs.json',JSON.stringify({rigs,textures}));
console.log('Original rigs built:',Object.keys(rigs),needed.size,'textures');
