import test from 'node:test';
import assert from 'node:assert/strict';
import {Game,LEVELS,PHONEMES,shuffled,cornArc} from '../dist/engine.js';
const advance=(g,seconds)=>{for(let i=0;i<Math.ceil(seconds*100);i++)g.update(.01);};
test('48-symbol inventory has exact group sizes and no duplicates',()=>{assert.deepEqual(Object.values(PHONEMES).map(a=>a.length),[12,8,28]);assert.equal(new Set(LEVELS[3].symbols).size,48);});
test('every level is directly selectable in both modes',()=>{for(const difficulty of ['easy','hard'])for(let level=0;level<4;level++){const g=new Game({difficulty,level});assert.equal(g.level.id,level);assert.equal(g.zombies.length,1);assert.equal(g.total,[12,8,28,48][level]);}});
test('shuffled deck preserves coverage and differs from previous even under repeated randomness',()=>{let a=shuffled(PHONEMES.mono,[],()=>.5);let b=shuffled(PHONEMES.mono,a,()=>.5);assert.notDeepEqual(a,b);assert.deepEqual([...a].sort(),[...b].sort());});
test('hard mode spawns at five second intervals into distinct rows, max three',()=>{const g=new Game({difficulty:'hard',random:()=>.5});advance(g,4.9);assert.equal(g.zombies.length,1);advance(g,.2);assert.equal(g.zombies.length,2);advance(g,5);assert.equal(g.zombies.length,3);assert.equal(new Set(g.zombies.map(z=>z.row)).size,3);advance(g,5);assert.equal(g.spawned,3);});
test('only a matching row can fire, repeat clicks cannot duplicate shots',()=>{const g=new Game();const r=g.zombies[0].row;assert.equal(g.fire((r+1)%5),false);assert.equal(g.fire(r),true);assert.equal(g.fire(r),false);assert.equal(g.projectiles.length,1);assert.equal(g.killed,0);advance(g,2);assert.equal(g.killed,1);});
test('repeater emits two delayed peas and only scores one kill',()=>{const g=new Game({level:1});g.fire(g.zombies[0].row);assert.equal(g.projectiles.length,2);assert.equal(g.projectiles[1].age,-.15);advance(g,3);assert.equal(g.killed,1);assert.equal(g.drain().filter(e=>e.type==='shoot').length,2);});
test('corn rises, bends and falls; scoring only occurs after windup and impact',()=>{assert.equal(cornArc(0,8).height,0);assert.ok(cornArc(.5,8).height>cornArc(.1,8).height);assert.equal(cornArc(1,8).height,0);assert.equal(cornArc(1,8).x,8);const g=new Game({level:3});advance(g,2);g.fire(g.zombies[0].row);advance(g,g.timing.cannonWindup+2);assert.equal(g.killed,0);advance(g,.4);assert.equal(g.killed,1);});
test('pause freezes walking, animation time, shots and spawn timers',()=>{const g=new Game({difficulty:'hard'});g.fire(g.zombies[0].row);advance(g,.3);g.pause();const s=JSON.stringify(g);advance(g,15);assert.equal(JSON.stringify(g),s);g.resume();advance(g,.2);assert.ok(g.time>.4);});
test('eating has a visible interval, then removes plant and loses',()=>{const g=new Game({timing:{zombieMin:10,zombieMax:10}});advance(g,.9);assert.equal(g.zombies[0].state,'eating');assert.equal(g.state,'playing');advance(g,3);assert.equal(g.state,'lost');assert.equal(g.plants[g.zombies[0].row].alive,false);assert.ok(g.drain().some(e=>e.type==='bite'));});
test('easy waits through death animation and one second before replacing target',()=>{const g=new Game();g.fire(g.zombies[0].row);while(g.killed===0)g.update(.01);advance(g,1.5);assert.equal(g.spawned,1);advance(g,1.2);assert.equal(g.spawned,2);assert.equal(g.zombies.length,1);});
test('all eight games can finish and never advance to another level',()=>{for(const difficulty of ['easy','hard'])for(let level=0;level<4;level++){const g=new Game({difficulty,level});for(let tick=0;tick<150000&&g.state==='playing';tick++){for(const z of g.zombies)g.fire(z.row);g.update(.02);}assert.equal(g.state,'won',difficulty+' '+level);assert.equal(g.killed,g.total);assert.equal(g.spawned,g.total);assert.equal(g.level.id,level);assert.equal(g.zombies.length,0);}});
test('new game has no state from a discarded round',()=>{const g=new Game({level:3,difficulty:'hard'});g.fire(g.zombies[0].row);advance(g,1);const b=new Game({level:0});assert.equal(b.time,0);assert.equal(b.projectiles.length,0);assert.equal(b.killed,0);assert.equal(b.spawned,1);});

test('stationary boss deploys ordinary targets; only landed targets can be shot',()=>{
 const g=new Game({level:3,random:()=>.5}),z=g.zombies[0],x=z.x;
 assert.equal(g.boss.state,'throwing');assert.notEqual(z.sprite,'boss');assert.equal(g.fire(z.row),false);
 advance(g,1);assert.equal(z.x,x);assert.equal(z.eaten,0);
 g.pause();const state=JSON.stringify(g);advance(g,8);assert.equal(JSON.stringify(g),state);g.resume();
 advance(g,1);assert.equal(g.boss.state,'idle');assert.equal(z.state,'walking');assert.ok(z.x<x);assert.equal(g.fire(z.row),true);
});
test('hard boss throws one at five second intervals, maximum three distinct rows',()=>{
 const g=new Game({level:3,difficulty:'hard',random:()=>.3});advance(g,4.99);assert.equal(g.spawned,1);advance(g,.03);assert.equal(g.spawned,2);assert.equal(g.zombies.filter(z=>z.state==='deploying').length,1);
 advance(g,10);assert.equal(g.spawned,3);assert.equal(new Set(g.zombies.map(z=>z.row)).size,3);
});
test('48th answer lowers boss head, final shell hits before original death and flag sequence',()=>{
 const g=new Game({level:3});let guard=0;
 while(g.killed<48||g.zombies.length){for(const z of g.zombies)g.fire(z.row);g.update(.1);assert.ok(++guard<10000);}
 assert.equal(g.boss.state,'lowering');assert.equal(g.state,'playing');assert.equal(g.spawned,48);
 advance(g,g.timing.bossHeadSeconds+.02);assert.equal(g.boss.state,'final-shot');assert.equal(g.projectiles[0].target,'boss');
 advance(g,g.timing.cannonWindup+g.timing.cannonSeconds+.02);assert.equal(g.boss.state,'dying');assert.equal(g.state,'playing');
 g.drain();g.pause();const state=JSON.stringify(g);advance(g,8);assert.equal(JSON.stringify(g),state);g.resume();
 advance(g,g.timing.bossDeathSeconds);assert.equal(g.state,'playing');assert.equal(g.boss.explosions,14);
 advance(g,g.timing.bossFlagSeconds);assert.equal(g.state,'playing','flag must finish raising before its hold');
 advance(g,.5);assert.equal(g.state,'won');assert.equal(g.killed,48);assert.equal(g.drain().filter(e=>e.type==='win').length,1);
});
