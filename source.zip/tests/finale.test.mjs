import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {RigPlayer} from '../dist/rig.js';
import {FINALE,EXPLOSION,bossPose,mergeBounds,worldBounds,fitCamera,cameraAt,createExplosion,explosionBounds,partPose,explosionLayers,explosionOrigin} from '../dist/finale.js';
import {TIMING,BOSS_EXPLOSIONS} from '../dist/engine.js';
const data=JSON.parse(fs.readFileSync(new URL('../dist/assets/rigs.json',import.meta.url)));
const rig=new RigPlayer(data,data.textures);
test('camera includes all original death and flag frames plus particle extents',()=>{
 let bounds={left:0,top:0,right:1200,bottom:740};const frames=[];
 for(const [state,seconds] of [['lowering',TIMING.bossHeadSeconds],['dying',TIMING.bossDeathSeconds+2]]){
  for(let t=0;t<seconds;t+=1/72){const p=bossPose(state,t,t,TIMING.bossDeathSeconds);const b=worldBounds(rig.bounds('boss',p.animation,p.time,p.options));frames.push(b);bounds=mergeBounds(bounds,b);}
 }
 for(let i=0;i<14;i++)for(const random of [()=>0,()=>.999]){const e=createExplosion(i,explosionOrigin(rig,i,BOSS_EXPLOSIONS[i]*TIMING.bossDeathSeconds),0,random);bounds=mergeBounds(bounds,explosionBounds(e,data.textures.IMAGE_REANIM_ZOMBOSS_PARTICLES));}
 const camera=fitCamera(bounds);
 for(const b of [...frames,bounds]){assert.ok(b.left*camera.scale+camera.x>=FINALE.padding-.001);assert.ok(b.right*camera.scale+camera.x<=1200-FINALE.padding+.001);assert.ok(b.top*camera.scale+camera.y>=FINALE.top+FINALE.padding-.001);assert.ok(b.bottom*camera.scale+camera.y<=740-FINALE.bottom-FINALE.padding+.001);}
 assert.deepEqual(cameraAt(camera,0),{scale:1,x:0,y:0});assert.deepEqual(cameraAt(camera,1),cameraAt(camera,100));
});
test('particles follow fixed ballistic paths and stop rendering at their lifetime',()=>{
 const e=createExplosion(2,{x:700,y:250},0,()=>.75),json=JSON.stringify(e);
 assert.equal(e.parts.length,3);assert.ok(e.parts.every(p=>p.frame>=0&&p.frame<5));
 for(const p of e.parts){assert.equal(partPose(p,p.delay-.01),null);const a=partPose(p,p.delay+.1),b=partPose(p,p.delay+.2),c=partPose(p,p.delay+.3);assert.ok(Math.abs(c.y-2*b.y+a.y-EXPLOSION.gravity*.01)<1e-7);assert.equal(partPose(p,p.delay+.81),null);assert.deepEqual(partPose(p,.4),partPose(p,.4));}
 assert.equal(JSON.stringify(e),json);
});
test('original smoke curves hold brightness then fade, with sampled scale ranges',()=>{
 const e=createExplosion(0,{x:0,y:0},0,()=>.5);
 assert.equal(explosionLayers(e,.1)[0].alpha,.5);assert.equal(explosionLayers(e,.35)[1].alpha,1);
 assert.ok(explosionLayers(e,.49)[1].alpha<.11);assert.equal(explosionLayers(e,0)[2].alpha,0);assert.deepEqual(explosionLayers(e,.5),[]);
 assert.equal(explosionLayers(e,.25)[0].scale,.9);
});
test('driver raises flag before looping; final frame bounds include the attachment',()=>{
 const t=TIMING.bossDeathSeconds*.99;
 assert.equal(bossPose('dying',t,0,TIMING.bossDeathSeconds).options.driverAnimation,'anim_flag');
 assert.equal(bossPose('dying',t+FINALE.flagRaise+.01,0,TIMING.bossDeathSeconds).options.driverAnimation,'anim_flag_loop');
 const p=bossPose('dying',t+.2,0,TIMING.bossDeathSeconds),b=rig.bounds('boss',p.animation,p.time,p.options),without=rig.bounds('boss',p.animation,p.time,{...p.options,driver:false});
 assert.ok(b.left<=without.left&&b.top<=without.top&&b.bottom>=without.bottom);
});
