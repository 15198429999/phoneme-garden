import fs from 'node:fs/promises';
import path from 'node:path';
const manifest=[];
export async function blob(repo, entry, out) {
  const response=await fetch('https://api.github.com/repos/'+repo+'/git/blobs/'+entry.sha);
  if(!response.ok) throw new Error(response.status+' '+entry.path);
  const j=await response.json();
  const buffer=Buffer.from(j.content,'base64');
  await fs.mkdir(path.dirname(out),{recursive:true}); await fs.writeFile(out,buffer);
  manifest.push({file:out,source:'https://github.com/'+repo+'/blob/'+entry.sha+'/'+entry.path,repo,path:entry.path,sha:entry.sha,bytes:buffer.length});
}
if(process.argv[2]==='initial') {
 const j=JSON.parse(await fs.readFile('research/jiangnangame.json'));
 const wanted={
 'images/Plants/Peashooter/Peashooter.gif':'pea.gif', 'images/Plants/Repeater/Repeater.gif':'repeater.gif',
 'images/Zombies/Zombie/Zombie.gif':'zombie-walk.gif','images/Zombies/Zombie/ZombieAttack.gif':'zombie-eat.gif',
 'images/Zombies/Zombie/ZombieDie.gif':'zombie-die.gif','images/Zombies/Zombie/ZombieHead.gif':'zombie-head.gif',
 'images/Zombies/Zombie/ZombieLostHead.gif':'zombie-losthead.gif',
 'images/Zombies/ConeheadZombie/ConeheadZombie.gif':'cone-walk.gif','images/Zombies/ConeheadZombie/ConeheadZombieAttack.gif':'cone-eat.gif',
 'images/Zombies/BucketheadZombie/BucketheadZombie.gif':'bucket-walk.gif','images/Zombies/BucketheadZombie/BucketheadZombieAttack.gif':'bucket-eat.gif',
 'audio/chomp.mp3':'chomp.mp3','audio/groan3.mp3':'groan.mp3','audio/losemusic.mp3':'lose.mp3','audio/winmusic.mp3':'win.mp3','audio/buttonclick.mp3':'click.mp3','audio/cherrybomb.mp3':'explode.mp3',
 'LICENSE-ENGLISH.md':'SOURCE-LICENSE.txt'};
 for (const [src,dest] of Object.entries(wanted)) {const e=j.tree.find(x=>x.path===src);if(e){await blob(j.repo,e,'dist/assets/'+dest);console.log(dest)}else console.log('MISSING',src)}
 await fs.writeFile('research/asset-sources.json',JSON.stringify(manifest,null,2));
 const s=JSON.parse(await fs.readFile('research/Patoke.json'));
 for (const file of ['Lawn/Zombie.cpp','Lawn/Projectile.cpp','Lawn/Plant.cpp','LawnApp.cpp','Sexy.TodLib/TodFoley.cpp']) {let e=s.tree.find(x=>x.path===file);if(e)await blob(s.repo,e,'research/'+path.basename(file))}
}
